import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';

const root = new URL('./dist/', import.meta.url);
const mime = {
  html: 'text/html; charset=utf-8',
  css: 'text/css; charset=utf-8',
  js: 'text/javascript; charset=utf-8',
  mjs: 'text/javascript; charset=utf-8',
  svg: 'image/svg+xml',
  json: 'application/json',
  bin: 'application/octet-stream',
  wasm: 'application/wasm',
  woff2: 'font/woff2',
  txt: 'text/plain; charset=utf-8'
};
const port = Number(process.env.CHESS_PORT || 4173);
createServer(async (request, response) => {
  try {
    const pathname = decodeURIComponent(new URL(request.url, root.origin === 'null' ? 'http://localhost' : root.origin).pathname);
    const file = new URL(pathname === '/' ? 'index.html' : '.' + pathname, root);
    if (!file.href.startsWith(root.href)) throw Error('Outside static directory');
    const body = await readFile(file);
    response.writeHead(200, { 'Content-Type': mime[file.pathname.split('.').at(-1)] || mime.txt });
    response.end(body);
  } catch {
    response.writeHead(404);
    response.end();
  }
}).listen(port, '127.0.0.1', () => console.log('http://127.0.0.1:' + port));
