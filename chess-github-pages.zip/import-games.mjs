import { createZstdDecompress } from 'node:zlib';
import { Readable } from 'node:stream';
import { createInterface } from 'node:readline';
import { mkdir, readFile, stat, writeFile } from 'node:fs/promises';

const base = 'https://database.lichess.org/broadcast/';
const destination = new URL('./dist/games/', import.meta.url);
const alphabet = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
await mkdir(destination, {recursive: true});

async function download(url) {
  const response = await fetch(url, {signal: AbortSignal.timeout(180000)});
  if (response.status === 429) {
    const delay = Math.max(60, Number(response.headers.get('retry-after')) || 0);
    console.log('Rate limit, waiting ' + delay + 's');
    await new Promise(resolve => setTimeout(resolve, delay * 1000));
    return download(url);
  }
  if (!response.ok) throw new Error(url + ' · ' + response.status);
  return response;
}

function encode(id) {
  let value = 0;
  for (const char of id) value = value * 62 + alphabet.indexOf(char);
  return value;
}

const files = (await (await download(base + 'list.txt')).text()).trim().split(/\s+/);
async function indexMonth(url) {
  const month = url.match(/(\d{4}-\d{2})\.pgn\.zst$/)[1];
  const output = new URL(month + '.bin', destination);
  const existing = await stat(output).catch(() => null);
  if (existing?.size && existing.size % 12 === 0) return [month, existing.size / 12];
  const response = await download(url);
  const input = Readable.fromWeb(response.body).pipe(createZstdDecompress());
  const chapters = new Map();
  for await (const line of createInterface({input, crlfDelay: Infinity})) {
    const match = line.match(/^\[GameURL "https:\/\/lichess\.org\/broadcast\/.+\/([a-z\d]{8})\/([a-z\d]{8})"\]$/i);
    if (match) chapters.set(match[2], match[1]);
  }
  if (!chapters.size) throw new Error('No game URLs for ' + month);
  const records = Buffer.alloc(chapters.size * 12);
  let offset = 0;
  for (const [chapter, study] of chapters) {
    records.writeUIntBE(encode(study), offset, 6);
    records.writeUIntBE(encode(chapter), offset + 6, 6);
    offset += 12;
  }
  await writeFile(output, records);
  console.log(month, chapters.size);
  return [month, chapters.size];
}

const months = [];
for (const url of files) {
  months.push(await indexMonth(url));
}
const seen = new Set();
for (const entry of months) {
  const url = new URL(entry[0] + '.bin', destination);
  const records = await readFile(url);
  let end = 0;
  for (let offset = 0; offset < records.length; offset += 12) {
    const chapter = records.readUIntBE(offset + 6, 6);
    if (seen.has(chapter)) continue;
    seen.add(chapter);
    if (end !== offset) records.copy(records, end, offset, offset + 12);
    end += 12;
  }
  if (end !== records.length) {
    await writeFile(url, records.subarray(0, end));
    entry[1] = end / 12;
  }
}
await writeFile(new URL('index.json', destination), JSON.stringify(months));
console.log('Total:', months.reduce((sum, [, count]) => sum + count, 0));

