# Шахматы

Игра в Chess960 со Stockfish и два режима тренировки на позициях из турнирных партий Lichess. Движок работает в браузере. Для турнирных заданий браузер загружает PGN через API Lichess.

## Локальный запуск

Из папки проекта запустите `node serve.mjs` и откройте [локальный сайт](http://127.0.0.1:4173/). Установка зависимостей и сборка не требуются. Для обновления индекса партий через `node import-games.mjs` нужен Node.js 24 или новее.

## GitHub Pages

1. Загрузите исходники проекта в ветку `main` своего репозитория GitHub. В корне репозитория должны быть `.github/workflows/pages.yml` и `dist/index.html`.
2. Откройте **Settings → Pages → Build and deployment** и выберите **GitHub Actions** в поле **Source**.
3. В разделе **Actions** запустите **Deploy chess site to GitHub Pages** для первого деплоя. Последующие изменения в `main` будут публиковаться автоматически. Ссылка на сайт появится в результате деплоя.

Workflow публикует содержимое папки `dist/`. Ключи API и сервер для сайта не нужны. Относительные адреса поддерживают размещение в подпапке репозитория.

Для загрузки из ZIP распакуйте архив и создайте пустой репозиторий GitHub. Команды выполняются из папки с этим README.

```sh
git init -b main
git add .
git commit -m "Publish chess site"
git remote add origin https://github.com/OWNER/REPO.git
git push -u origin main
```

Замените `OWNER/REPO` на владельца и имя созданного репозитория.

[Документация GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages)

## Сторонние компоненты

- **Stockfish.js 19.0.1** · [исходники и инструкция сборки](https://github.com/nmrugg/stockfish.js/tree/v19.0.1) · [GPL v3](dist/vendor/stockfish-GPL.txt)
- **chess.js** · [BSD-2-Clause](dist/vendor/chess-LICENSE.txt)
- **chess.mjs 2.5.1** · [MIT](dist/vendor/chess960/LICENSE) · [уведомление BSD-2-Clause в исходнике Chess.js](dist/vendor/chess960/Chess.js)
- **Фигуры Colin M. L. Burnett** · [авторство и лицензия в репозитории Lichess](https://github.com/lichess-org/lila/blob/master/COPYING.md) · [GPL v2+](dist/pieces/GPL-2.0.txt)
- **Inter** · [SIL Open Font License 1.1](dist/vendor/inter-OFL.txt)
- **Индекс Lichess Broadcasts** · [источник, преобразования и лицензия CC BY-SA 4.0](dist/games/NOTICE.txt)
